﻿"""Route modules for CMMS."""
