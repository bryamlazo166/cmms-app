
import sqlite3
import os

DB_PATH = os.path.join(os.getcwd(), 'instance', 'cmms_v2.db')

def migrate_db():
    if not os.path.exists(DB_PATH):
        print(f"Error: Database {DB_PATH} not found.")
        return

    print(f"Migrating database: {DB_PATH}")
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    columns_to_add = [
        ('lead_time', 'INTEGER DEFAULT 0'),
        ('abc_class', "TEXT DEFAULT 'C'"),
        ('xyz_class', "TEXT DEFAULT 'Z'"),
        ('safety_stock', 'INTEGER DEFAULT 0'),
        ('rop', 'INTEGER DEFAULT 0'),
        ('max_stock', 'INTEGER DEFAULT 0'),
        ('min_order_qty', 'INTEGER DEFAULT 1')
    ]

    for col_name, col_type in columns_to_add:
        try:
            print(f"Adding column: {col_name}...")
            cursor.execute(f"ALTER TABLE warehouse_items ADD COLUMN {col_name} {col_type}")
            print(f"Column {col_name} added successfully.")
        except sqlite3.OperationalError as e:
            if "duplicate column name" in str(e):
                print(f"Column {col_name} already exists. Skipping.")
            else:
                print(f"Error adding column {col_name}: {e}")
    
    conn.commit()
    conn.close()
    print("Migration finished.")

if __name__ == '__main__':
    migrate_db()
